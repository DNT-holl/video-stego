import cv2
import numpy as np
import sys

def get_shuffled_coordinates(height, width, seed_key):
    """
    Hàm này phải giống hệt hàm trong file random_embed.py
    để đảm bảo quỹ đạo trích xuất khớp với quỹ đạo nhúng.
    """
    coords = []
    h_trunc = height - (height % 8)
    w_trunc = width - (width % 8)
    
    for i in range(0, h_trunc, 8):
        for j in range(0, w_trunc, 8):
            coords.append((i, j))
            
    # Đồng bộ hóa bộ sinh số ngẫu nhiên bằng Khóa
    np.random.seed(seed_key)
    np.random.shuffle(coords)
    return coords

def extract_with_key(stego_video, secret_key):
    cap = cv2.VideoCapture(stego_video)
    if not cap.isOpened():
        print(f"Lỗi: Không thể mở video {stego_video}")
        sys.exit(1)

    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    # Lấy lại danh sách tọa độ dựa trên khóa cung cấp
    shuffled_coords = get_shuffled_coordinates(height, width, secret_key)
    
    delta = 16
    extracted_bits = ""
    
    # Số lượng ký tự muốn trích xuất (để tránh in ra toàn bộ rác của video)
    # Giả sử file secret.txt gốc dài khoảng 100 ký tự (tương đương 800 bits)
    max_bits = 800 

    print(f"Đang trích xuất dữ liệu với mã PIN: {secret_key}...")

    # Chỉ đọc khung hình đầu tiên (giống như quá trình nhúng)
    ret, frame = cap.read()
    if ret:
        ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        Y, _, _ = cv2.split(ycrcb)

        # Duyệt qua các tọa độ đã xáo trộn
        for (i, j) in shuffled_coords:
            if len(extracted_bits) >= max_bits:
                break

            block = np.float32(Y[i:i+8, j:j+8])
            dct_block = cv2.dct(block)

            dc_val = dct_block[0, 0]
            
            # Khôi phục bit bằng thuật toán QIM
            quantized = np.round(dc_val / delta) * delta
            if dc_val > quantized:
                extracted_bits += '1'
            else:
                extracted_bits += '0'

    cap.release()

    # Chuyển đổi chuỗi bit thành văn bản
    chars = []
    for i in range(0, len(extracted_bits), 8):
        byte = extracted_bits[i:i+8]
        if len(byte) == 8:
            # Bỏ qua các ký tự điều khiển (không in được) để màn hình không bị lỗi hiển thị
            char_code = int(byte, 2)
            if 32 <= char_code <= 126 or char_code in [9, 10, 13]: # ASCII chuẩn
                chars.append(chr(char_code))
            else:
                chars.append('?') # Đánh dấu các ký tự rác do sai khóa

    message = "".join(chars)
    print("-" * 40)
    print("THÔNG ĐIỆP KHÔI PHỤC ĐƯỢC:")
    print(message)
    print("-" * 40)
    
    # Dấu hiệu nhận biết sai khóa: thông điệp chứa quá nhiều ký tự '?'
    if message.count('?') > (len(message) * 0.5):
        print("[!] Cảnh báo: Thông điệp chứa nhiều ký tự rác.")
        print("[!] Có thể bạn đã nhập SAI mã PIN (Secret Key).")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Sử dụng: python3 random_extract.py <video_stego> <PIN>")
        sys.exit(1)
        
    stego_video = sys.argv[1]
    secret_key = int(sys.argv[2])
    extract_with_key(stego_video, secret_key)
