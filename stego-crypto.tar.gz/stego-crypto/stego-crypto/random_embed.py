import cv2
import numpy as np
import sys

def text_to_bits(text):
    return ''.join([format(ord(c), '08b') for c in text])

def get_shuffled_coordinates(height, width, seed_key):
    """Tạo và xáo trộn danh sách tọa độ các block 8x8 dựa trên Khóa"""
    coords = []
    h_trunc = height - (height % 8)
    w_trunc = width - (width % 8)
    
    # Tạo danh sách tất cả các tọa độ (i, j) của các block
    for i in range(0, h_trunc, 8):
        for j in range(0, w_trunc, 8):
            coords.append((i, j))
            
    # Đặt Seed và xáo trộn ngẫu nhiên
    np.random.seed(seed_key)
    np.random.shuffle(coords)
    return coords

def embed_with_key(input_video, secret_file, secret_key, output_video):
    with open(secret_file, 'r', encoding='utf-8') as f:
        bits = text_to_bits(f.read())
        
    bit_len = len(bits)
    bit_idx = 0
    delta = 16

    cap = cv2.VideoCapture(input_video)
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    out = cv2.VideoWriter(output_video, cv2.VideoWriter_fourcc(*'mp4v'), fps, (width, height))

    # Lấy danh sách tọa độ đã được xáo trộn bằng Khóa
    shuffled_coords = get_shuffled_coordinates(height, width, secret_key)
    
    if bit_len > len(shuffled_coords):
        print(f"Lỗi: Video quá nhỏ, chỉ chứa được {len(shuffled_coords)} bits.")
        return

    print(f"Đang nhúng với khóa {secret_key}...")

    # Đọc frame đầu tiên (Giả sử ta chỉ giấu vào frame đầu để đơn giản hóa logic Lab)
    ret, frame = cap.read()
    if ret:
        ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
        Y, Cr, Cb = cv2.split(ycrcb)

        # Duyệt qua các tọa độ NGẪU NHIÊN thay vì tuần tự
        for (i, j) in shuffled_coords:
            if bit_idx >= bit_len:
                break

            block = np.float32(Y[i:i+8, j:j+8])
            dct_block = cv2.dct(block)

            dc_val = dct_block[0, 0]
            quantized = np.round(dc_val / delta) * delta
            
            if int(bits[bit_idx]) == 1:
                dct_block[0, 0] = quantized + (delta / 2)
            else:
                dct_block[0, 0] = quantized - (delta / 2)

            idct_block = cv2.idct(dct_block)
            Y[i:i+8, j:j+8] = np.clip(idct_block, 0, 255)
            bit_idx += 1

        merged = cv2.merge([Y, Cr, Cb])
        frame = cv2.cvtColor(merged, cv2.COLOR_YCrCb2BGR)
        out.write(frame)

    # Ghi lại các frame còn lại mà không sửa đổi
    while True:
        ret, frame = cap.read()
        if not ret: break
        out.write(frame)

    cap.release()
    out.release()
    print("Hoàn tất!")

if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Sử dụng: python3 random_embed.py <video_in> <file_txt> <PIN> <video_out>")
        sys.exit(1)
    
    embed_with_key(sys.argv[1], sys.argv[2], int(sys.argv[3]), sys.argv[4])
