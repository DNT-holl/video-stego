import cv2
import numpy as np

def extract_bits_from_frame(frame, needed, bit_idx):
    bits = []
    ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
    y_channel = ycrcb[:,:,0].astype(np.float32)
    h, w = y_channel.shape
    for i in range(0, h, 8):
        for j in range(0, w, 8):
            if bit_idx >= needed:
                return bits, bit_idx, True
            block = y_channel[i:i+8, j:j+8]
            if block.shape != (8,8): continue
            dct = cv2.dct(block)
            bit = int(dct[0,1]) & 1
            bits.append(str(bit))
            bit_idx += 1
    return bits, bit_idx, False

def bits_to_string(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte)<8: break
        chars.append(chr(int(''.join(byte), 2)))
    return ''.join(chars)

def main():
    import sys
    if len(sys.argv)<2:
        print("Usage: python3 stego_ac_extract.py output.mp4")
        return
    video_path = sys.argv[1]
    bits_out = []
    bit_idx = 0
    # USER: Adjust this to expected bit count!
    # For demo, try to extract up to 8000 bits (1000 chars)
    needed_bits = 8000

    cap = cv2.VideoCapture(video_path)
    while cap.isOpened() and bit_idx < needed_bits:
        success, frame = cap.read()
        if not success:
            break
        bits, bit_idx, done = extract_bits_from_frame(frame, needed_bits, bit_idx)
        bits_out.extend(bits)
        if done:
            break
    cap.release()
    # Try to reconstruct message
    message = bits_to_string(bits_out)
    print("[RESULT]")
    print(message)
    with open("extracted_message.txt","w") as f:
        f.write(message)

if __name__=="__main__":
    main()
