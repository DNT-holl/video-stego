import cv2
import numpy as np

def read_message_bits(msgpath):
    with open(msgpath, 'r') as f:
        message = f.read()
    bits = ''.join([format(ord(c), '08b') for c in message])
    return bits

def embed_message_to_frame(frame, bits, bit_idx):
    # Convert to YCrCb, work on Y channel (grayscale)
    ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
    y_channel = ycrcb[:,:,0].astype(np.float32)
    h, w = y_channel.shape
    for i in range(0, h, 8):
        for j in range(0, w, 8):
            if bit_idx >= len(bits):
                ycrcb[:,:,0] = np.clip(y_channel, 0, 255).astype(np.uint8)
                return ycrcb, bit_idx, True  # done
            block = y_channel[i:i+8, j:j+8]
            if block.shape != (8,8): continue
            dct = cv2.dct(block)
            # Embed into the [0][1] (AC) coefficient (avoid DC at [0][0])
            coeff = dct[0,1]
            bit = int(bits[bit_idx])
            dct[0,1] = int(coeff) & ~1 | bit # Set LSB of AC
            # Inverse DCT
            block_idct = cv2.idct(dct)
            y_channel[i:i+8, j:j+8] = block_idct
            bit_idx += 1
    ycrcb[:,:,0] = np.clip(y_channel, 0, 255).astype(np.uint8)
    return ycrcb, bit_idx, False

def main():
    import sys
    if len(sys.argv)<3:
        print("Usage: python3 stego_ac_embed.py input.mp4 message.txt")
        return
    video_path = sys.argv[1]
    message_path = sys.argv[2]
    output_path = 'output.mp4'

    message_bits = read_message_bits(message_path)
    total_bits = len(message_bits)
    print(f"[INFO] Need to embed {total_bits} bits")

    cap = cv2.VideoCapture(video_path)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = None

    frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    bit_idx = 0
    frame_idx = 0
    while cap.isOpened():
        success, frame = cap.read()
        if not success: break
        if out is None:
            out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
        ycrcb, bit_idx, done = embed_message_to_frame(frame, message_bits, bit_idx)
        frame_embed = cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2BGR)
        out.write(frame_embed)
        frame_idx += 1
        if done:
            print(f"[INFO] Done embedding at frame {frame_idx}")
            # Copy rest of frames as-is
            while cap.isOpened():
                ok, f = cap.read()
                if not ok: break
                out.write(f)
            break
    cap.release()
    if out: out.release()
    print(f"[SUCCESS] Embedded message to output.mp4")

if __name__=="__main__":
    main()
