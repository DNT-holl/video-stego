import cv2
import numpy as np

def read_message_bits(msgfile):
    with open(msgfile, 'r') as f:
        text = f.read()
    return ''.join([format(ord(ch), '08b') for ch in text])

def embed_bit(block, bit):
    dct = cv2.dct(block)
    # Chọn 2 hệ số AC gần DC (ví dụ [0,1] và [1,0])
    a, b = dct[0,1], dct[1,0]
    # Phép cân bằng: bit=1 thì a > b, bit=0 thì a < b
    if bit == '1' and a <= b:
        dct[0,1] = b + abs(a-b) + 1
    elif bit == '0' and a >= b:
        dct[1,0] = a + abs(a-b) + 1
    # Inverse DCT
    new_block = cv2.idct(dct)
    return new_block

def embed_message_frame(frame, bits, bit_idx):
    ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
    y = ycrcb[:,:,0].astype(np.float32)
    h, w = y.shape
    done = False
    for i in range(0, h, 8):
        for j in range(0, w, 8):
            if bit_idx >= len(bits):
                done = True
                break
            block = y[i:i+8, j:j+8]
            if block.shape != (8,8): continue
            y[i:i+8, j:j+8] = embed_bit(block, bits[bit_idx])
            bit_idx += 1
        if done: break
    ycrcb[:,:,0] = np.clip(y,0,255).astype(np.uint8)
    return cv2.cvtColor(ycrcb, cv2.COLOR_YCrCb2BGR), bit_idx, done

def main():
    import sys
    if len(sys.argv) < 3:
        print("Usage: python3 stego_devbal_embed.py input.mp4 message.txt")
        return
    in_video = sys.argv[1]
    msg_file = sys.argv[2]
    out_video = "output.mp4"

    bits = read_message_bits(msg_file)
    total = len(bits)

    cap = cv2.VideoCapture(in_video)
    fps = cap.get(cv2.CAP_PROP_FPS)
    width  = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(out_video, fourcc, fps, (width, height))

    bit_idx = 0
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret: break
        newframe, bit_idx, done = embed_message_frame(frame, bits, bit_idx)
        out.write(newframe)
        if done:
            # copy phần còn lại
            while True:
                ret2, f2 = cap.read()
                if not ret2: break
                out.write(f2)
            break
    cap.release()
    out.release()
    print(f"[SUCCESS] Đã giấu dữ liệu vào {out_video}")

if __name__ == "__main__":
    main()
